require 'test_helper'

class SectionsHelperTest < ActionView::TestCase
end
