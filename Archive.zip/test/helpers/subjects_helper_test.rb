require 'test_helper'

class SubjectsHelperTest < ActionView::TestCase
end
