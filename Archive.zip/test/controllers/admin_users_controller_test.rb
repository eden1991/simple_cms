require 'test_helper'

class AdminUsersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
